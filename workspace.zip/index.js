

/* eslint-disable  func-names */
/* eslint-disable  no-console */

const Alexa = require('ask-sdk');
// Create the DynamoDB service object
var AWS = require('aws-sdk');
var req = require('request')

const getDefinationHandler = {

  
    canHandle(handlerInput) {
      const request = handlerInput.requestEnvelope.request;
      return (request.type === 'IntentRequest'
          && request.intent.name === 'defination');
    },
  

    handle(handlerInput) {
      var request = require(request);

      var options ={
        url :'https://od-api.oxforddictionaries.com/api/v1/entries/en/postman',
        headers: {
          'app_id':'cd90b1e1',
          'app_key': '72eb367d610c52794329d72509cf58f7'
        }
      };
      request(options,function(error,response,body){
        console.log('body', body);
      });
  
      var speechOutput =  body;
    return resolve (handlerInput.responseBuilder
     .speak(speechOutput)
   //  .withSimpleCard(SKILL_NAME, correctOrIncorrect)
     .getResponse());
    } 
    
}


const GetNewFactHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'LaunchRequest'
      || (request.type === 'IntentRequest'
        && request.intent.name === 'GetNewFactIntent');

  },
  handle(handlerInput) {
   var  ddb = new AWS.DynamoDB({apiVersion: '2012-10-08'});
     
    const factArr = ["rug","cat","apple","ball","test","note","index"];
    const factIndex = Math.floor(Math.random() * factArr.length);
    const randomFact = factArr[factIndex];
    const speechOutput = GET_FACT_MESSAGE + randomFact;
    var params = {
  TableName: 'SpellMasterData',
  Item: {
    'userId' : {S: randomFact},
  }
};
// Call DynamoDB to add the item to the table
ddb.putItem(params, function(err, data) {
  if (err) {
    console.log("Error", err);
  } else {
    console.log("Success", data);
  }
});
    return handlerInput.responseBuilder
      .speak(speechOutput)
      .withSimpleCard(SKILL_NAME, randomFact)
      .getResponse();
  },
};

const SpellCheckHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return (request.type === 'IntentRequest'
        && request.intent.name === 'SpellCheck');
  },
   handle(handlerInput) {
 return new Promise((resolve) => {  
   const attributes =  handlerInput.attributesManager.getSessionAttributes();
   const answerSlot = handlerInput.requestEnvelope.request.intent.slots.letter.value.toLowerCase();
    console.log("test1", answerSlot);
	var correctOrIncorrect = answerSlot;
    var speechOutput ;
var  ddb = new AWS.DynamoDB({apiVersion: '2012-10-08'});

var params = {
  TableName: 'SpellMasterData',
  Key: {
    'userId' : {S: answerSlot},
  },
  ProjectionExpression: 'userId'
};

// Call DynamoDB to read the item from the table

 ddb.getItem(params, function(err, data) {
  if (err) {
     console.log("Error1", err);
 
   } 
   else {
    if(data.Item!=undefined)
    {
    console.log("Success", data);
    var answer = data.Item.userId.S;
    if(answer==answerSlot)
    {
      correctOrIncorrect="correct";
       console.log("test 2", correctOrIncorrect);
    }
    else
    {
       correctOrIncorrect="Incorrect";
       console.log("test 2.1", correctOrIncorrect);
    }
    }
    else
    {
      correctOrIncorrect="Incorrect";
      console.log("test 2.2", correctOrIncorrect);
      
    }
    console.log("test 2.3", correctOrIncorrect);
    speechOutput =  GET_SPELLING_MATCH_MESSAGE + correctOrIncorrect;
	   return resolve (handlerInput.responseBuilder
      .speak(speechOutput)
      .withSimpleCard(SKILL_NAME, correctOrIncorrect)
      .getResponse());
  }

}
);

  });
	  	
  },
};

const HelpHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {
    return handlerInput.responseBuilder
      .speak(HELP_MESSAGE)
      .reprompt(HELP_REPROMPT)
      .getResponse();
  },
};

const ExitHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && (request.intent.name === 'AMAZON.CancelIntent'
        || request.intent.name === 'AMAZON.StopIntent');
  },
  handle(handlerInput) {
    return handlerInput.responseBuilder
      .speak(STOP_MESSAGE)
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

    return handlerInput.responseBuilder.getResponse();
  },
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    console.log(`Error handled: ${error.message}`);

    return handlerInput.responseBuilder
      .speak('Sorry, an error occurred.')
      .reprompt('Sorry, an error occurred.')
      .getResponse();
  },
};

const SKILL_NAME = 'Space Facts';
const GET_FACT_MESSAGE = 'Here\'s your word, spell: ';
const GET_SPELLING_MATCH_MESSAGE = 'Your answer is: ';
const HELP_MESSAGE = 'I can help you to practice spelling, or, you can say exit... What can I help you with?';
const HELP_REPROMPT = 'What can I help you with?';
const STOP_MESSAGE = 'Goodbye!';

const data = [
  'A year on Mercury is just 88 days long.',
  'Despite being farther from the Sun, Venus experiences higher temperatures than Mercury.',
  'Venus rotates counter-clockwise, possibly because of a collision in the past with an asteroid.',
  'On Mars, the Sun appears about half the size as it does on Earth.',
  'Earth is the only planet not named after a god.',
  'Jupiter has the shortest day of all the planets.',
  'The Milky Way galaxy will collide with the Andromeda Galaxy in about 5 billion years.',
  'The Sun contains 99.86% of the mass in the Solar System.',
  'The Sun is an almost perfect sphere.',
  'A total solar eclipse can happen once every 1 to 2 years. This makes them a rare event.',
  'Saturn radiates two and a half times more energy into space than it receives from the sun.',
  'The temperature inside the Sun can reach 15 million degrees Celsius.',
  'The Moon is moving approximately 3.8 cm away from our planet every year.',
];

const skillBuilder = Alexa.SkillBuilders.standard();

exports.handler = skillBuilder
  .addRequestHandlers(
    GetNewFactHandler,
    SpellCheckHandler,
    HelpHandler,
    ExitHandler,
    SessionEndedRequestHandler
  )
  .addErrorHandlers(ErrorHandler)
  .lambda();
